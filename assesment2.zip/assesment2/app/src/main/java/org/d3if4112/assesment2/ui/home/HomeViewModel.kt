package org.d3if4112.assesment2.ui.home

import androidx.lifecycle.ViewModel
import org.d3if4112.assesment2.db.SuhuDao

class HomeViewModel (private val db: SuhuDao) : ViewModel(){
//    private val navigasi = MutableLiveData<>

}