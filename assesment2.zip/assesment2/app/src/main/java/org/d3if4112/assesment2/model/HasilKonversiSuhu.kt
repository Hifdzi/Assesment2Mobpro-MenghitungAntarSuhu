package org.d3if4112.assesment2.model

data class HasilKonversiSuhu(
    val suhuCelcius: Float,
    val suhuConvert: String
)