package org.d3if4112.assesment2.model

enum class KategoriSuhu{
    REAMUR, FARENHIT, KELVIN
}
